function mudar() {
    var div = document.getElementById('jorge');
    var txt = document.getElementById('txt');

    div.style = "color = #ffaa55";


}