var a = 30, b = 60, c = 6;

if (a > b && a > c && b > c) {
    alert(a + " > " + b + " > " + c);
} else if (b > a && b > c && a > c) {
    alert(b + " > " + a + " > " + c);
} else if (b > c && b > a && c > a) {
    alert(c + " > " + a + " > " + b);
}
