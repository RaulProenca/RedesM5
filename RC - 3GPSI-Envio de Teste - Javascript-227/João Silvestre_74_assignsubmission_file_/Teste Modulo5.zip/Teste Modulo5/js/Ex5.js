function maisculas() {
    var txtFrase = document.getElementById('txtFrase');


    txtFrase.i
}