var data = new Date();
if (data.getDay() != 6 && data.getDay() != 0) {
    alert("É dia da semana.");
} else {
    alert("É dia da fim-de-semana.");
}