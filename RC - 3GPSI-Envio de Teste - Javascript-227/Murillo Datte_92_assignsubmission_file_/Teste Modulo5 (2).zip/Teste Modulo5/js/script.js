

function trocar() {


    var Arvore1 = document.getElementById("Arv1");

    var num1 = Math.floor(Math.random() * 5);

    if (num1 == 2) {
        Arvore1.src = "images/arv2.jpg";
    }
    else if (num1 == 3) {
        Arvore1.src = "images/arv3.jpg";
    }
    else if (num1 == 4) {
        Arvore1.src = "images/arv4.jpg";
    }

}
//ex4
function mudacor() {
    var cor = document.getElementsByClassName("color");
    color = parseInt(cor.value);



}
//ex5
function mudatipo() {
    var text = getElementById("txtFrase");
    text.toUpperCase();



}

//6
function name(params) {

}




