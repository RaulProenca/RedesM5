function letras() {
    var frase_inicial = document.getElementById("txtFrase");
    var frase_depois = document.getElementById("lblFrase");

    frase_depois.innerHTML = frase_inicial.value.toUpperCase();
    /* frase_depois = frase_inicial.toUpperCase();*/




    /*var letra = palavras[i].charAt(0).toUpperCase();
    palavras[i] = letra + palavras[i].slice(1);*/
}

function adicionar() {
    var texto = document.getElementById("text");

    texto.value = nDias * 25 + segmento + extras + " euros";

}


function imprimir() {


}



/*
function custofinal() {
    var inputdias = document.getElementById("nDias");
    var inputRes = document.getElementById("resultado");
    var nDias = parseInt(inputdias.value);
    var inputSegmento = document.getElementsByName("segmento");
    var segmento = 0;
    var labelopcoes = document.getElementById("opcoes");
    var selectMarca = document.getElementById("marca");
    var indice = selectMarca.selectedIndex;
    var marca = selectMarca.options[indice].text;


    var segmentoDesc = "Utilitário/Sedan";
    var extrasDesc = " ";
    if(inputSegmento[1].checked){
        segmento = 5 * nDias;
        segmentoDesc = inputSegmento[1].value;
    }else if(inputSegmento[2].checked){
        segmento = 10 * nDias;
        segmentoDesc = inputSegmento[2].value;
    }


    var inputExtras = document.getElementsByName("extras");
    var extras = 0;
    for (let i = 0; i < inputExtras.length; i++) {
        if (inputExtras[i].checked) {
            extras += 15;
            extrasDesc += inputExtras[i].value + " ";

        }

    }

    inputRes.value = nDias * 25 + segmento + extras + " euros";

    labelopcoes.innerHTML = "numero de dias: " + inputdias.value + "  <br> marca: " + marca + "<br> segmento:   " + segmentoDesc + "<br> extras " + extrasDesc ;

}*/
