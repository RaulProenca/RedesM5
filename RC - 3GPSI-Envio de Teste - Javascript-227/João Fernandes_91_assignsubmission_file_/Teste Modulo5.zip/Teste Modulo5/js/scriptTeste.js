function imagemaleatoria() {
    var imagem1 = document.getElementById("imagem1");




    num = [Math.floor(Math.random() * 3)];

    if (num == 1) {
        imagem1.src = "images/arv2.jpg";
    }
    else
        if (num == 2) {
            imagem1.src = "images/arv3.jpg";
        }
        else
            if (num == 3) {
                imagem1.src = "images/arv4.jpg";
            }

}

function trocar() {
    var frase = document.getElementById("frase1");
    for (let i = 0; i < frase; i++) {
        frase[i].classList.toggle("Obrigado");
    };

}

function maiuscola() {
    var frase = document.getElementById("txtFrase");
    frase.toUpperCase();
}