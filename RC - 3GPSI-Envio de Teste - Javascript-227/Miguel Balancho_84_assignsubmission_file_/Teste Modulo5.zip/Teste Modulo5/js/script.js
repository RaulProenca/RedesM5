function Ex1() {
    var num1 = 10;
    var num2 = 20;
    var num3 = 30;

    if (num1 > num2 && num2 > num3 && num1 > num2) {
        alert("a ordem decrescente é: " + num1 + " " + num2 + " " + num3);
    } else if (num1 > num2 && num3 > num2 && num1 > num3) {
        alert("a ordem decrescente é: " + num1 + " " + num3 + " " + num2);
    } else if (num2 > num1 && num1 > num3 && num2 > num1) {
        alert("a ordem decrescente é: " + num2 + " " + num1 + " " + num3);
    } else if (num2 > num1 && num3 > num1 && num2 > num3) {
        alert("a ordem decrescente é: " + num2 + " " + num3 + " " + num1);
    } else if (num3 > num1 && num1 > num2 && num3 > num1) {
        alert("a ordem decrescente é: " + num3 + " " + num1 + " " + num2);
    } else if (num3 > num1 && num2 > num1 && num3 > num2) {
        alert("a ordem decrescente é: " + num3 + " " + num2 + " " + num1);
    } else
        alert("uns dos numeros são iguais");

}

function Ex2() {
    var data1 = new Date();

    if (data1.getDay() == 0 || data1.getDay() == 6) {
        alert("fim de semana");
    } else
        alert("dia de semana");

}

function Ex3() {
    var random = Math.floor(Math.random() * 4);
    var img = document.getElementById("arvore");

    switch (random) {
        case 0:
            img.src = "images/arv1.jpg";
            break;
        case 1:
            img.src = "images/arv2.jpg";
            break;
        case 2:
            img.src = "images/arv3.jpg";
            break;
        case 3:
            img.src = "images/arv4.jpg";
            break;

    }
}

function mudarcor() {
    var divex4 = document.getElementById("divEx4");
    divex4.style = "background-color: #ffaa55;";
    var texto = document.getElementById("texto")
    texto.textContent = "Obrigado";
}

function voltarcor() {
    var divex4 = document.getElementById("divEx4");
    divex4.style = "background-color: #77aa00;";
    var texto = document.getElementById("texto")
    var texto = document.getElementById("texto")
    texto.textContent = "Passe o rato por cima";
}

function Ex5() {
    var frase = document.getElementById("txtFrase");
    var label = document.getElementById("lblFrase");
    var newfrase = frase.value;

    label.innerHTML = newfrase.toUpperCase();
}

var arrayex6 = [];

function Ex6Adicionar() {
    var numeros = document.getElementById("txtArray");
    arrayex6.push(numeros.value);

}

function Ex6Imprimir() {
    var label = document.getElementById("lblValues");
    var texto = ""
    for (let i = 0; i < arrayex6.length; i++) {
        texto += "Elemento no index " + i + ": " + arrayex6[i].value + "<br>";
    }

    label.value = texto;
}

function Ex7() {
    var label = document.getElementById("lblRes")
    var radio = document.getElementsByName("volumearea");
    var num = document.getElementById("txtRaio");
    var raio = num.value;
    var res;
    if (radio[0].checked)
        res = (4 * Math.PI * Math.pow(raio, 3)) / 3;
    else
        res = 4 * Math.PI * Math.pow(raio, 3);

    label.innerHTML = "O Resultado é " + res;

}